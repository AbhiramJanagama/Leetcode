# Leetcode
A set of my leetcode solutions using java and python.
